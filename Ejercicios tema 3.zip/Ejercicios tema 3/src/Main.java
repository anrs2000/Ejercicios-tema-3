public class Main {
    public static void main(String[] args) {
        suma(10, 20, 40);
    }
    public static int suma(int a, int b, int c) {
        System.out.println(a+b+c);
        return(a+b+c);}
}

public class Main {
    public static void main(String[] args) {
        coche miCoche = new coche();
        miCoche.SumarPuerta();
        System.out.println(miCoche.puertas);
    }
}
class coche {
    public int puertas = 4;
    public void SumarPuerta(){
        this.puertas++;
    }
}